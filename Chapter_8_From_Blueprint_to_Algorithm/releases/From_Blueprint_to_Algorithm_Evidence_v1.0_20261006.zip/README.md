# Chapter 8 evidence package

The records, original figures and supporting data accompany **From Blueprint to Algorithm: How Neural Networks Generate Answers**. Begin with `EVIDENCE_INDEX.md`; read `SOURCE_AVAILABILITY.md` for provenance and limitations. Links to the report and earlier chapters are available in the [online publication](https://github.com/walkingrui-bot/Data-Oriented-Modelling-Reports/tree/main/Chapter_8_From_Blueprint_to_Algorithm). The archive contains 34 experiment files and nine original source figures, plus numerical figure data and report tables. No experiment was rerun for this edition.

Run `sha256sum -c SHA256SUMS.txt` from this directory to verify the archived evidence and index files.

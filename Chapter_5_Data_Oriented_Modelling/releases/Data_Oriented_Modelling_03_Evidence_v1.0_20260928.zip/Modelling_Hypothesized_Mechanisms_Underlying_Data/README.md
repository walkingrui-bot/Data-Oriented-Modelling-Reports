# Evidence collection

Chapter 5, Report 03: Modelling Hypothesized Mechanisms Underlying Data. Open EVIDENCE_INDEX.md for the experiment map and REPRODUCTION_GUIDE.md for calculations. The publication package supplies the English Word and online report.

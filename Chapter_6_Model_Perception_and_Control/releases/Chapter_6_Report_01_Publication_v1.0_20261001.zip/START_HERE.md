# Model Perception and Action Control

Chapter 6, Report 01. Open Chapter_6_Model_Perception_and_Control/README.md and follow the report and evidence links. The integrated English report is provided in Word and Markdown with 56 embedded figures.

Online edition: https://github.com/walkingrui-bot/Data-Oriented-Modelling-Reports/tree/main/Chapter_6_Model_Perception_and_Control

The evidence index identifies recovered outputs and missing row-level records. External raw datasets are excluded.

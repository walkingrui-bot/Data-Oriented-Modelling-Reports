# Data Zoo · Subreport 04

Open [Genomic Predictive Geometry and Model Capacity](Chapter_4_Data_Zoo/Genomic_Predictive_Geometry_and_Model_Capacity/README.md) for the English Word report, online text, figures, tables, experiment evidence and reproduction guide. Directory paths follow the public chapter structure. Provider observations are acquired separately.

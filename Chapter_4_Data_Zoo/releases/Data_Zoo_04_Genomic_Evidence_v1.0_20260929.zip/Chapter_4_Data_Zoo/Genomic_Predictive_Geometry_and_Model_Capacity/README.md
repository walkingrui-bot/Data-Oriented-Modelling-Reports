# Genomic evidence collection

[Evidence index](EVIDENCE_INDEX.md) · [Reproduction guide](REPRODUCTION_GUIDE.md) · [Source availability](SOURCE_AVAILABILITY.md) · [Full report](https://github.com/walkingrui-bot/Data-Oriented-Modelling-Reports/blob/main/Chapter_4_Data_Zoo/Genomic_Predictive_Geometry_and_Model_Capacity/REPORT_EN.md)

This collection preserves the chapter directory structure and includes derived results, figures, protocols, source identities, and available analysis scripts. Provider observations are excluded.

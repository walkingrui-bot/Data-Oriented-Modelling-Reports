# Data Zoo · Subreport 04 · Evidence collection

Open the [evidence index](Chapter_4_Data_Zoo/Genomic_Predictive_Geometry_and_Model_Capacity/EVIDENCE_INDEX.md) and [reproduction guide](Chapter_4_Data_Zoo/Genomic_Predictive_Geometry_and_Model_Capacity/REPRODUCTION_GUIDE.md). The [English report](https://github.com/walkingrui-bot/Data-Oriented-Modelling-Reports/blob/main/Chapter_4_Data_Zoo/Genomic_Predictive_Geometry_and_Model_Capacity/REPORT_EN.md) and Word edition are available in the full publication package. Provider observations are acquired separately.

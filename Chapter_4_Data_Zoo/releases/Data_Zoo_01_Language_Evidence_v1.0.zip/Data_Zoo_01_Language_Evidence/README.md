# Data Zoo 01 Language evidence

Language Structure and Control Geometry · English edition v1.0 · 27 September 2026

This collection contains fifteen recovered independent experiment archives in extracted form, all 69 original report figures, 79 source-table transcriptions, source records and analysis-coverage notes.

Four studies have report extracts only: LSP-002, LSP-003, TOOL-CHAIN-GEOMETRY-006B and NATLANG-COMPAT-004A. Their independent analysis archives were not recovered. The extracted tables and figures are labeled as report evidence, not newly recomputed experiment outputs.

Open [EVIDENCE_INDEX.md](EVIDENCE_INDEX.md) for the study map, [SOURCE_AVAILABILITY.md](SOURCE_AVAILABILITY.md) for external input sources, [REPRODUCTION_GUIDE.md](REPRODUCTION_GUIDE.md) for code coverage, and [PUBLICATION_NOTES.md](PUBLICATION_NOTES.md) for the two identified source-record issues and engineering scope.

External source datasets are not bundled. This evidence collection contains authored analyses, controlled experiment materials, derived outputs, figures and source metadata.

The Internal Factory of Language Models — interactive views

Open index.html. Each view contains its own recorded data and works offline.

01 reasoning_chain.html: CoT-MOTION-002, eight controlled recurrent trajectories.
02 generation_factory.html: TOKEN-MOTION-037, internal assembly before a TEXT/ACT output.
provenance_ledger.html: routing histories for all 386 source positions.

Full reports: https://github.com/walkingrui-bot/Data-Oriented-Modelling-Reports/tree/main/Chapter_7_The_Internal_Factory_of_Language_Models
